package kr.team1.app.web.counterpick;

public class CounterpickHeroBean {
	
	private String no;
	private String position;
	private String heroname;
	private String heroimg;
	private String heroname_english;
	private int index;
	
	private int votenum;

	public String getNo() {
		return no;
	}

	public void setNo(String no) {
		this.no = no;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getHeroname() {
		return heroname;
	}

	public void setHeroname(String heroname) {
		this.heroname = heroname;
	}

	public String getHeroimg() {
		return heroimg;
	}

	public void setHeroimg(String heroimg) {
		this.heroimg = heroimg;
	}

	public String getHeroname_english() {
		return heroname_english;
	}

	public void setHeroname_english(String heroname_english) {
		this.heroname_english = heroname_english;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public int getVotenum() {
		return votenum;
	}

	public void setVotenum(int votenum) {
		this.votenum = votenum;
	}

	

	
	
	
}
